Bonus has been finished. Please check it out in `main.cpp`, `rasterizer.hpp`, `rasterizer.cpp`, `image_msaa_2x2.png`.

> `color_buffer` from: [戴皓天](http://games-cn.org/forums/topic/%E3%80%90%E6%80%BB%E7%BB%93%E3%80%91msaa%E4%B8%AD%E9%BB%91%E7%BA%BF%E9%97%AE%E9%A2%98%E7%9A%84%E5%87%BA%E7%8E%B0%E5%8E%9F%E5%9B%A0%E4%BB%A5%E5%8F%8A%E8%A7%A3%E5%86%B3%E6%96%B9%E6%A1%88/)

[Ubuntu使用VSCode编译C++17](https://www.bilibili.com/read/cv10737689)